import { useState } from 'react';
import { Checkbox } from "@/components/ui/checkbox";
import { DataPlugin } from '@shared/schema';
import DataFlow from '../ui/data-flow';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";

const AgentBuilder = () => {
  const [agentName, setAgentName] = useState('Financial Insights Agent');
  const [baseModel, setBaseModel] = useState('Nous-Hermes 2 Yi 34B');
  const [systemPrompt, setSystemPrompt] = useState(
    'You are a financial insights agent with access to real-time market data through MCP plugins. Your goal is to provide accurate, up-to-date information about financial markets, cryptocurrency prices, and related news. Always specify the source and timestamp of your data.'
  );
  
  const [testInput, setTestInput] = useState('');
  const [testOutput, setTestOutput] = useState<string[]>([
    'Agent responses will appear here...'
  ]);
  
  const [plugins, setPlugins] = useState<DataPlugin[]>([
    { id: 'financial', name: 'Financial Data', enabled: true, apiKey: '' },
    { id: 'news', name: 'News & Events', enabled: true, apiKey: '' },
    { id: 'onchain', name: 'On-chain Data', enabled: false, apiKey: '' },
    { id: 'research', name: 'Research Papers', enabled: false, apiKey: '' }
  ]);
  
  const togglePlugin = (id: string) => {
    setPlugins(plugins.map(plugin => 
      plugin.id === id ? { ...plugin, enabled: !plugin.enabled } : plugin
    ));
  };
  
  const handleTestQuery = () => {
    if (!testInput.trim()) return;
    
    // Clear current output and show thinking state
    setTestOutput(['User: ' + testInput, 'Agent is thinking...']);
    
    // Simulate a response after a short delay
    setTimeout(() => {
      let response = '';
      
      if (testInput.toLowerCase().includes('bitcoin') || testInput.toLowerCase().includes('btc')) {
        response = `Agent: Bitcoin is currently trading at $68,223.45. This represents a +2.7% increase in the last 24 hours. Trading volume is $42.3 billion.\n\nData retrieved via Financial Data plugin at ${new Date().toLocaleTimeString()}`;
      } else if (testInput.toLowerCase().includes('ethereum') || testInput.toLowerCase().includes('eth')) {
        response = `Agent: Ethereum is currently trading at $3,571.28. This represents a -0.8% decrease in the last 24 hours. Trading volume is $19.6 billion.\n\nData retrieved via Financial Data plugin at ${new Date().toLocaleTimeString()}`;
      } else {
        response = `Agent: I'd be happy to help with that query. Since this is a demo, I can show you real-time data for common cryptocurrencies like Bitcoin (BTC) or Ethereum (ETH).\n\nTry asking: "What's the current Bitcoin price?" or "How is Ethereum performing today?"\n\nMCP enables me to connect to financial APIs for live data`;
      }
      
      setTestOutput(['User: ' + testInput, response]);
      setTestInput('');
    }, 1500);
  };
  
  return (
    <section id="agent-builder" className="py-16 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">MCP Agent Builder</h2>
          <p className="text-neutral-300 max-w-2xl mx-auto">Create your own context-aware agent by connecting to real-time data sources through MCP.</p>
        </div>
        
        <div className="bg-neutral-800 border border-neutral-700 rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-700 flex items-center justify-between">
            <h3 className="font-medium">Agent Configuration</h3>
            <div className="flex items-center space-x-3">
              <span className="text-sm text-neutral-400">Status:</span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/20 text-success">
                <span className="w-1.5 h-1.5 mr-1 bg-success rounded-full"></span>
                Ready
              </span>
            </div>
          </div>
          
          <div className="grid md:grid-cols-5">
            {/* Sidebar options */}
            <div className="md:col-span-2 border-r border-neutral-700 bg-neutral-900/50">
              <div className="p-6">
                <div className="mb-6">
                  <label className="block text-neutral-300 mb-2 text-sm">Agent Name</label>
                  <input 
                    type="text" 
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg py-2 px-3 focus:outline-none focus:border-primary"
                  />
                </div>
                
                <div className="mb-6">
                  <label className="block text-neutral-300 mb-2 text-sm">Base Model</label>
                  <select 
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg py-2 px-3 focus:outline-none focus:border-primary"
                    value={baseModel}
                    onChange={(e) => setBaseModel(e.target.value)}
                  >
                    <option>Claude 3 Opus</option>
                    <option>GPT-4o</option>
                    <option>Nous-Hermes 2 Yi 34B</option>
                    <option>Llama 3 70B</option>
                  </select>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-center mb-2">
                    <label className="block text-neutral-300 text-sm">MCP Plugins</label>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-2 text-neutral-400 hover:text-neutral-200 focus:outline-none">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-xs">MCP plugins connect your agent to external data sources and provide real-time information to enhance responses.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="space-y-2">
                    {plugins.map((plugin) => (
                      <div key={plugin.id} className="flex items-center p-3 bg-neutral-800 rounded-lg border border-neutral-700">
                        <Checkbox 
                          id={`plugin-${plugin.id}`} 
                          checked={plugin.enabled}
                          onCheckedChange={() => togglePlugin(plugin.id)}
                          className="mr-3"
                        />
                        <div className="flex-grow">
                          <label htmlFor={`plugin-${plugin.id}`} className="font-medium cursor-pointer">
                            {plugin.name}
                          </label>
                          {plugin.id === 'financial' && (
                            <p className="text-xs text-neutral-400">Real-time market data, crypto prices, stock information</p>
                          )}
                          {plugin.id === 'news' && (
                            <p className="text-xs text-neutral-400">Breaking news, market events, company announcements</p>
                          )}
                          {plugin.id === 'onchain' && (
                            <p className="text-xs text-neutral-400">Blockchain transactions, wallet data, smart contracts</p>
                          )}
                          {plugin.id === 'research' && (
                            <p className="text-xs text-neutral-400">Academic research, financial reports, technical papers</p>
                          )}
                        </div>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button className="text-neutral-400 hover:text-neutral-200 mr-2 focus:outline-none">
                                <i className="ri-information-line"></i>
                              </button>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs" side="left">
                              {plugin.id === 'financial' && (
                                <div className="space-y-2">
                                  <h4 className="font-semibold text-xs">Financial Data Plugin</h4>
                                  <p className="text-xs">Connects to financial APIs providing:</p>
                                  <ul className="text-xs list-disc pl-4 space-y-1">
                                    <li>Real-time cryptocurrency prices</li>
                                    <li>Stock market data</li>
                                    <li>Market indices and trends</li>
                                    <li>Currency exchange rates</li>
                                  </ul>
                                  <p className="text-xs opacity-75 italic">Updates every 60 seconds</p>
                                </div>
                              )}
                              {plugin.id === 'news' && (
                                <div className="space-y-2">
                                  <h4 className="font-semibold text-xs">News & Events Plugin</h4>
                                  <p className="text-xs">Connects to news APIs providing:</p>
                                  <ul className="text-xs list-disc pl-4 space-y-1">
                                    <li>Breaking news from major outlets</li>
                                    <li>Financial press releases</li>
                                    <li>Market-moving announcements</li>
                                    <li>Sentiment analysis of news stories</li>
                                  </ul>
                                  <p className="text-xs opacity-75 italic">Updates every 15 minutes</p>
                                </div>
                              )}
                              {plugin.id === 'onchain' && (
                                <div className="space-y-2">
                                  <h4 className="font-semibold text-xs">On-chain Data Plugin</h4>
                                  <p className="text-xs">Connects to blockchain nodes providing:</p>
                                  <ul className="text-xs list-disc pl-4 space-y-1">
                                    <li>Blockchain transaction data</li>
                                    <li>Smart contract interactions</li>
                                    <li>Wallet holdings and transfers</li>
                                    <li>DeFi protocol statistics</li>
                                  </ul>
                                  <p className="text-xs opacity-75 italic">Updates in near real-time</p>
                                </div>
                              )}
                              {plugin.id === 'research' && (
                                <div className="space-y-2">
                                  <h4 className="font-semibold text-xs">Research Papers Plugin</h4>
                                  <p className="text-xs">Connects to academic & financial databases:</p>
                                  <ul className="text-xs list-disc pl-4 space-y-1">
                                    <li>Published economic research</li>
                                    <li>Financial analyst reports</li>
                                    <li>Technical papers and whitepapers</li>
                                    <li>Industry reports and statistics</li>
                                  </ul>
                                  <p className="text-xs opacity-75 italic">Updated weekly</p>
                                </div>
                              )}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        {plugin.id === 'financial' && <i className="ri-bank-line text-neutral-400"></i>}
                        {plugin.id === 'news' && <i className="ri-newspaper-line text-neutral-400"></i>}
                        {plugin.id === 'onchain' && <i className="ri-link-m text-neutral-400"></i>}
                        {plugin.id === 'research' && <i className="ri-file-paper-2-line text-neutral-400"></i>}
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-neutral-300 mb-2 text-sm">Agent System Prompt</label>
                  <textarea 
                    rows={4} 
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg py-2 px-3 focus:outline-none focus:border-primary text-sm"
                    placeholder="You are a financial insights agent with access to real-time market data..."
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                  />
                </div>
              </div>
            </div>
            
            {/* MCP Flow Visualization */}
            <div className="md:col-span-3 p-6">
              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <h3 className="font-medium">MCP Data Flow</h3>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-2 text-neutral-400 hover:text-neutral-200 focus:outline-none">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <div className="space-y-2">
                          <h4 className="font-semibold text-xs">Multi-Context Planning</h4>
                          <p className="text-xs">MCP enables the agent to identify, source, and integrate data from multiple contexts to provide complete answers.</p>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="bg-neutral-900 p-4 rounded-lg border border-neutral-700 h-80 relative">
                  <div className="flex items-center justify-center h-full">
                    <DataFlow enabledPlugins={plugins.filter(p => p.enabled).map(p => p.id)} />
                  </div>
                  
                  {/* Interactive tooltip points on the diagram */}
                  <div className="absolute top-6 left-[60px]">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-xs text-primary hover:bg-primary/30 focus:outline-none">
                            1
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="bottom">
                          <p className="text-xs">User query is processed to determine intent and required data</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  
                  <div className="absolute top-[110px] left-[200px]">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-xs text-primary hover:bg-primary/30 focus:outline-none">
                            2
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="top">
                          <p className="text-xs">MCP Agent analyzes query and selects appropriate data sources</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  
                  <div className="absolute top-[130px] left-[50px]">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-xs text-primary hover:bg-primary/30 focus:outline-none">
                            3
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="right">
                          <p className="text-xs">Specialized plugins retrieve data from external sources</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  
                  <div className="absolute bottom-10 right-10">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-xs text-primary hover:bg-primary/30 focus:outline-none">
                            4
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="left">
                          <p className="text-xs">Agent synthesizes information and generates a comprehensive response</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-4">Test Your Agent</h3>
                <div className="mb-4 bg-neutral-900 rounded-lg border border-neutral-700 p-4 h-40 overflow-y-auto whitespace-pre-line">
                  {testOutput.map((line, index) => (
                    <p 
                      key={index} 
                      className={line.includes('thinking') ? 'text-neutral-400 typing' : (line.startsWith('User:') ? 'font-medium' : '')}
                    >
                      {line}
                    </p>
                  ))}
                </div>
                <div className="flex">
                  <input 
                    type="text" 
                    className="flex-grow bg-neutral-900 border border-neutral-700 rounded-l-lg py-2 px-3 focus:outline-none focus:border-primary" 
                    placeholder="Ask about financial data..."
                    value={testInput}
                    onChange={(e) => setTestInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleTestQuery()}
                  />
                  <button 
                    className="bg-primary hover:bg-primary-dark px-4 py-2 rounded-r-lg transition-colors"
                    onClick={handleTestQuery}
                    aria-label="Send test query"
                  >
                    <i className="ri-send-plane-fill"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="px-6 py-4 border-t border-neutral-700 flex items-center justify-between">
            <div className="text-sm text-neutral-400">
              <i className="ri-information-line mr-1"></i>
              <span>All API connections are secured and data is processed locally</span>
            </div>
            <div className="flex space-x-3">
              <button 
                className="px-4 py-2 border border-neutral-700 hover:border-neutral-500 rounded transition-colors"
                onClick={() => {
                  setAgentName('Financial Insights Agent');
                  setBaseModel('Nous-Hermes 2 Yi 34B');
                  setSystemPrompt('You are a financial insights agent with access to real-time market data through MCP plugins. Your goal is to provide accurate, up-to-date information about financial markets, cryptocurrency prices, and related news. Always specify the source and timestamp of your data.');
                  setPlugins([
                    { id: 'financial', name: 'Financial Data', enabled: true, apiKey: '' },
                    { id: 'news', name: 'News & Events', enabled: true, apiKey: '' },
                    { id: 'onchain', name: 'On-chain Data', enabled: false, apiKey: '' },
                    { id: 'research', name: 'Research Papers', enabled: false, apiKey: '' }
                  ]);
                }}
              >
                Reset
              </button>
              <button className="px-4 py-2 bg-primary hover:bg-primary-dark rounded transition-colors">
                Save Agent
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AgentBuilder;
