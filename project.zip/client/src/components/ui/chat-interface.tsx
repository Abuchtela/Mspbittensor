import { useState, useRef, useEffect } from 'react';

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  mcpDataUsed?: boolean;
}

interface ChatInterfaceProps {
  title?: string;
  initialMessages?: Message[];
  onSendMessage?: (message: string) => Promise<void>;
}

const ChatInterface = ({
  title = "AI Assistant",
  initialMessages = [],
  onSendMessage
}: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Scroll to bottom whenever messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      isUser: true,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    // If onSendMessage is provided, call it
    if (onSendMessage) {
      try {
        await onSendMessage(input);
      } catch (error) {
        // Add error message
        const errorMessage: Message = {
          id: Date.now().toString(),
          content: `Error: ${(error as Error).message || "Failed to get response"}`,
          isUser: false,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } else {
      // If no onSendMessage, simulate a response after a delay
      setTimeout(() => {
        const botResponse: Message = {
          id: Date.now().toString(),
          content: "I'm a demo chat interface. To see real responses, provide an onSendMessage handler.",
          isUser: false,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botResponse]);
        setIsLoading(false);
      }, 1000);
    }
  };
  
  return (
    <div className="flex flex-col bg-neutral-800 border border-neutral-700 rounded-lg h-full shadow-lg overflow-hidden">
      <div className="p-4 border-b border-neutral-700 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-primary/20 text-primary rounded flex items-center justify-center">
            <i className="ri-robot-line"></i>
          </div>
          <span className="ml-2 font-medium">{title}</span>
        </div>
        <div className="flex space-x-1 text-neutral-500">
          <button className="hover:text-white transition" aria-label="Refresh">
            <i className="ri-refresh-line"></i>
          </button>
          <button className="hover:text-white transition" aria-label="Settings">
            <i className="ri-settings-3-line"></i>
          </button>
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto p-4 space-y-4">
        {messages.map(message => (
          <div key={message.id} className={`flex space-x-2 ${message.isUser ? '' : 'justify-start'}`}>
            <div className={`w-8 h-8 ${message.isUser ? 'bg-neutral-700' : 'bg-primary'} rounded-full flex-shrink-0 flex items-center justify-center`}>
              <i className={message.isUser ? 'ri-user-line' : 'ri-robot-line'}></i>
            </div>
            <div className={`${message.isUser ? 'bg-neutral-700' : 'bg-neutral-800 border border-neutral-700'} rounded-lg p-3 max-w-[85%]`}>
              <p className="whitespace-pre-wrap">{message.content}</p>
              {message.mcpDataUsed && (
                <div className="mt-2 text-xs bg-neutral-800 rounded px-2 py-1 inline-block">
                  Live data via MCP
                </div>
              )}
              <div className="mt-1 text-xs text-neutral-400">
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex space-x-2">
            <div className="w-8 h-8 bg-primary rounded-full flex-shrink-0 flex items-center justify-center">
              <i className="ri-robot-line"></i>
            </div>
            <div className="bg-neutral-800 border border-neutral-700 rounded-lg p-3">
              <p className="typing">Thinking</p>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <form className="p-4 border-t border-neutral-700" onSubmit={handleSubmit}>
        <div className="relative">
          <input
            type="text"
            className="w-full bg-neutral-900 border border-neutral-700 rounded-lg py-3 px-4 pr-10 focus:outline-none focus:border-primary placeholder-neutral-500"
            placeholder="Type your message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
          />
          <button
            type="submit"
            className="absolute right-3 top-1/2 -translate-y-1/2 text-primary hover:text-white transition"
            disabled={isLoading}
            aria-label="Send message"
          >
            <i className="ri-send-plane-fill"></i>
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatInterface;
