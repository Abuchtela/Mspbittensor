const VolumeChart = () => {
  return (
    <svg width="100%" height="100%" viewBox="0 0 300 100">
      {/* Chart grid */}
      <line x1="40" y1="10" x2="40" y2="80" stroke="#334155" strokeWidth="1"/>
      <line x1="40" y1="80" x2="290" y2="80" stroke="#334155" strokeWidth="1"/>
      
      {/* Y-axis labels */}
      <text x="35" y="15" textAnchor="end" fill="#64748B" fontSize="8">$50B</text>
      <text x="35" y="35" textAnchor="end" fill="#64748B" fontSize="8">$40B</text>
      <text x="35" y="55" textAnchor="end" fill="#64748B" fontSize="8">$30B</text>
      <text x="35" y="75" textAnchor="end" fill="#64748B" fontSize="8">$20B</text>
      
      {/* X-axis labels */}
      <text x="40" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Mon</text>
      <text x="82" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Tue</text>
      <text x="124" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Wed</text>
      <text x="166" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Thu</text>
      <text x="208" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Fri</text>
      <text x="250" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Sat</text>
      <text x="290" y="92" textAnchor="middle" fill="#64748B" fontSize="8">Sun</text>
      
      {/* Volume bars */}
      <rect x="45" y="40" width="20" height="40" fill="#64748B" rx="2"/>
      <rect x="87" y="45" width="20" height="35" fill="#64748B" rx="2"/>
      <rect x="129" y="37" width="20" height="43" fill="#64748B" rx="2"/>
      <rect x="171" y="42" width="20" height="38" fill="#64748B" rx="2"/>
      <rect x="213" y="35" width="20" height="45" fill="#64748B" rx="2"/>
      <rect x="255" y="25" width="20" height="55" fill="#0066FF" rx="2"/>
      
      {/* Today indicator */}
      <text x="265" y="20" textAnchor="middle" fill="#F8FAFC" fontSize="8" fontWeight="bold">Today</text>
    </svg>
  );
};

export default VolumeChart;
