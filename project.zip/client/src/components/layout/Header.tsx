import { useState } from 'react';
import { Link } from 'wouter';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  return (
    <header className="border-b border-neutral-800 sticky top-0 z-10 bg-neutral-900/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="bg-primary p-2 rounded">
            <i className="ri-plug-2-line text-xl"></i>
          </div>
          <h1 className="font-display font-bold text-2xl bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Masa <span className="text-white">MCP</span>
          </h1>
        </div>
        
        <div className="flex items-center space-x-6">
          <nav className="hidden md:flex space-x-6">
            <a href="#agent-builder" className="text-neutral-300 hover:text-white transition">Agent Builder</a>
            <a href="#documentation" className="text-neutral-300 hover:text-white transition">Documentation</a>
            <a href="#challenges" className="text-neutral-300 hover:text-white transition">Challenges</a>
          </nav>
          <a 
            href="https://bit.ly/EndGame42" 
            className="hidden md:flex items-center space-x-1 bg-primary hover:bg-primary-dark px-4 py-2 rounded transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <span>Join Hackathon</span>
            <i className="ri-arrow-right-line"></i>
          </a>
          <button 
            className="md:hidden text-xl" 
            aria-label="Toggle mobile menu"
            onClick={toggleMobileMenu}
          >
            <i className={isMobileMenuOpen ? "ri-close-line" : "ri-menu-line"}></i>
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={`md:hidden ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-4 py-3 space-y-4 border-t border-neutral-800 bg-neutral-900">
          <a href="#agent-builder" className="block text-neutral-300 hover:text-white transition" onClick={() => setIsMobileMenuOpen(false)}>Agent Builder</a>
          <a href="#documentation" className="block text-neutral-300 hover:text-white transition" onClick={() => setIsMobileMenuOpen(false)}>Documentation</a>
          <a href="#challenges" className="block text-neutral-300 hover:text-white transition" onClick={() => setIsMobileMenuOpen(false)}>Challenges</a>
          <a 
            href="https://bit.ly/EndGame42" 
            className="flex items-center space-x-1 bg-primary hover:bg-primary-dark px-4 py-2 rounded transition-colors w-full justify-center"
            target="_blank"
            rel="noopener noreferrer"
          >
            <span>Join Hackathon</span>
            <i className="ri-arrow-right-line"></i>
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
