import { DataPlugin } from '@shared/schema';

// Define the structure of the API response for financial data
export interface FinancialData {
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
  lastUpdated: string;
}

// Define the structure of the API response for news data
export interface NewsItem {
  title: string;
  summary: string;
  url: string;
  source: string;
  publishedAt: string;
}

// Interface for MCP client responses
export interface MCPResponse {
  data: any;
  source: string;
  timestamp: string;
}

// Custom error class for MCP failures
export class MCPError extends Error {
  public statusCode?: number;
  public source?: string;
  
  constructor(message: string, statusCode?: number, source?: string) {
    super(message);
    this.name = 'MCPError';
    this.statusCode = statusCode;
    this.source = source;
  }
}

// The main MCP client class that handles connections to external data sources
export class MCPClient {
  private plugins: DataPlugin[];
  
  constructor(plugins: DataPlugin[]) {
    this.plugins = plugins.filter(plugin => plugin.enabled);
  }
  
  // Get crypto price data
  async getCryptoPrice(symbol: string): Promise<MCPResponse> {
    try {
      const response = await fetch(`/api/mcp/financial/crypto/${symbol}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch crypto data: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      const data = await response.json();
      return {
        data,
        source: 'Cryptocurrency API',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching crypto data: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
  
  // Get stock price data
  async getStockPrice(symbol: string): Promise<MCPResponse> {
    try {
      const response = await fetch(`/api/mcp/financial/stock/${symbol}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch stock data: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      const data = await response.json();
      return {
        data,
        source: 'Stock Market API',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching stock data: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
  
  // Get latest news
  async getLatestNews(topic: string, limit = 5): Promise<MCPResponse> {
    try {
      const response = await fetch(`/api/mcp/news?topic=${topic}&limit=${limit}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch news data: ${response.statusText}`,
          response.status,
          'news-api'
        );
      }
      
      const data = await response.json();
      return {
        data,
        source: 'News API',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching news data: ${(error as Error).message}`,
        500,
        'news-api'
      );
    }
  }
  
  // Get market data summary (volume, trends, etc.)
  async getMarketSummary(): Promise<MCPResponse> {
    try {
      const response = await fetch('/api/mcp/financial/market-summary');
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch market summary: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      const data = await response.json();
      return {
        data,
        source: 'Market Data API',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching market summary: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
  
  // Check if a specific plugin is enabled
  isPluginEnabled(pluginId: string): boolean {
    return this.plugins.some(plugin => plugin.id === pluginId && plugin.enabled);
  }
  
  // Get all enabled plugins
  getEnabledPlugins(): DataPlugin[] {
    return this.plugins.filter(plugin => plugin.enabled);
  }
}
