import { MCPError } from "../../mcpClient";

export interface NewsItem {
  title: string;
  summary: string;
  url: string;
  source: string;
  publishedAt: string;
  category: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
}

export class NewsPlugin {
  private apiKey: string;
  private baseUrl: string;
  
  constructor(apiKey: string = "") {
    this.apiKey = apiKey || process.env.NEWS_API_KEY || "";
    this.baseUrl = "https://api.example.com/news"; // Would be a real API in production
  }
  
  async getLatestNews(topic: string, limit: number = 5): Promise<NewsItem[]> {
    try {
      const response = await fetch(`/api/mcp/news?topic=${encodeURIComponent(topic)}&limit=${limit}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch news data: ${response.statusText}`,
          response.status,
          'news-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching news data: ${(error as Error).message}`,
        500,
        'news-api'
      );
    }
  }
  
  async searchNews(query: string, limit: number = 5): Promise<NewsItem[]> {
    try {
      const response = await fetch(`/api/mcp/news/search?query=${encodeURIComponent(query)}&limit=${limit}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to search news: ${response.statusText}`,
          response.status,
          'news-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error searching news: ${(error as Error).message}`,
        500,
        'news-api'
      );
    }
  }
  
  async getNewsBySentiment(topic: string, sentiment: 'positive' | 'negative' | 'neutral', limit: number = 5): Promise<NewsItem[]> {
    try {
      const response = await fetch(`/api/mcp/news/sentiment?topic=${encodeURIComponent(topic)}&sentiment=${sentiment}&limit=${limit}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch news by sentiment: ${response.statusText}`,
          response.status,
          'news-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching news by sentiment: ${(error as Error).message}`,
        500,
        'news-api'
      );
    }
  }
  
  // Get trending topics in news
  async getTrendingTopics(): Promise<string[]> {
    try {
      const response = await fetch('/api/mcp/news/trending');
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch trending topics: ${response.statusText}`,
          response.status,
          'news-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching trending topics: ${(error as Error).message}`,
        500,
        'news-api'
      );
    }
  }
}
