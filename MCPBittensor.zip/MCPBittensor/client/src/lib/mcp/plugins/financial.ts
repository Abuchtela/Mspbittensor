import { MCPError } from "../../mcpClient";

// Financial data types
export interface CryptoPrice {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
  lastUpdated: string;
}

export interface MarketSummary {
  totalMarketCap: number;
  btcDominance: number;
  topGainers: string[];
  topLosers: string[];
  marketSentiment: string;
  lastUpdated: string;
}

export interface StockPrice {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  lastUpdated: string;
}

// Financial plugin (used server-side to access real financial data)
export class FinancialPlugin {
  private apiKey: string;
  private baseUrl: string;
  
  constructor(apiKey: string = "") {
    this.apiKey = apiKey || process.env.FINANCIAL_API_KEY || "";
    this.baseUrl = "https://api.example.com/finance"; // Would be a real API in production
  }
  
  async getCryptoPrice(symbol: string): Promise<CryptoPrice> {
    try {
      const response = await fetch(`/api/mcp/financial/crypto/${symbol}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch crypto data: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching crypto data: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
  
  async getStockPrice(symbol: string): Promise<StockPrice> {
    try {
      const response = await fetch(`/api/mcp/financial/stock/${symbol}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch stock data: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching stock data: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
  
  async getMarketSummary(): Promise<MarketSummary> {
    try {
      const response = await fetch('/api/mcp/financial/market-summary');
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch market summary: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching market summary: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
  
  // Method to compare crypto performance over a specified time period
  async compareCryptoPerformance(symbol: string, days: number): Promise<any> {
    try {
      const response = await fetch(`/api/mcp/financial/crypto/${symbol}/history?days=${days}`);
      
      if (!response.ok) {
        throw new MCPError(
          `Failed to fetch crypto history: ${response.statusText}`,
          response.status,
          'financial-api'
        );
      }
      
      return await response.json();
    } catch (error) {
      if (error instanceof MCPError) {
        throw error;
      }
      throw new MCPError(
        `Error fetching crypto history: ${(error as Error).message}`,
        500,
        'financial-api'
      );
    }
  }
}
