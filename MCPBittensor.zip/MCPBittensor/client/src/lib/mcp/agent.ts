import { DataPlugin } from '@shared/schema';
import { MCPClient } from '../mcpClient';

interface MCPAgentOptions {
  name: string;
  model: string;
  systemPrompt: string;
  plugins: DataPlugin[];
}

interface MCPAgentResponse {
  text: string;
  sources?: Array<{
    name: string;
    url?: string;
    timestamp: string;
  }>;
  mcpData?: boolean;
}

export class MCPAgent {
  private name: string;
  private model: string;
  private systemPrompt: string;
  private mcpClient: MCPClient;
  
  constructor(options: MCPAgentOptions) {
    this.name = options.name;
    this.model = options.model;
    this.systemPrompt = options.systemPrompt;
    this.mcpClient = new MCPClient(options.plugins);
  }
  
  async processQuery(query: string): Promise<MCPAgentResponse> {
    console.log(`Processing query: "${query}" with model ${this.model}`);
    
    try {
      // Filter the query to determine if it's related to financial data
      if (this.isFinancialQuery(query)) {
        let responseData: any = null;
        let sourceName = '';
        
        // Handle crypto-related queries
        if (query.toLowerCase().includes('bitcoin') || query.toLowerCase().includes('btc')) {
          const response = await this.mcpClient.getCryptoPrice('BTC');
          responseData = response.data;
          sourceName = response.source;
          
          return {
            text: `Bitcoin is currently trading at $${responseData.price.toLocaleString()}. In the last 24 hours, it has ${responseData.change24h >= 0 ? 'increased' : 'decreased'} by ${Math.abs(responseData.change24h).toFixed(1)}%. The 24-hour trading volume is $${responseData.volume24h.toLocaleString()} billion.`,
            sources: [
              {
                name: sourceName,
                timestamp: response.timestamp
              }
            ],
            mcpData: true
          };
        } 
        // Handle Ethereum-related queries
        else if (query.toLowerCase().includes('ethereum') || query.toLowerCase().includes('eth')) {
          const response = await this.mcpClient.getCryptoPrice('ETH');
          responseData = response.data;
          sourceName = response.source;
          
          return {
            text: `Ethereum is currently trading at $${responseData.price.toLocaleString()}. In the last 24 hours, it has ${responseData.change24h >= 0 ? 'increased' : 'decreased'} by ${Math.abs(responseData.change24h).toFixed(1)}%. The 24-hour trading volume is $${responseData.volume24h.toLocaleString()} billion.`,
            sources: [
              {
                name: sourceName,
                timestamp: response.timestamp
              }
            ],
            mcpData: true
          };
        }
        // Handle market summary queries
        else if (this.isMarketOverviewQuery(query)) {
          const response = await this.mcpClient.getMarketSummary();
          responseData = response.data;
          sourceName = response.source;
          
          return {
            text: `Current market overview: The crypto market cap is $${responseData.totalMarketCap.toLocaleString()} trillion, with Bitcoin dominance at ${responseData.btcDominance.toFixed(1)}%. The top gainers in the last 24 hours are ${responseData.topGainers.join(', ')}. ${responseData.marketSentiment} sentiment is prevailing currently.`,
            sources: [
              {
                name: sourceName,
                timestamp: response.timestamp
              }
            ],
            mcpData: true
          };
        }
      }
      
      // Handle news-related queries
      if (this.isNewsQuery(query)) {
        const topic = this.extractNewsTopic(query);
        const response = await this.mcpClient.getLatestNews(topic);
        const newsItems = response.data;
        
        if (newsItems && newsItems.length > 0) {
          const newsItem = newsItems[0];
          return {
            text: `Latest news about ${topic}: "${newsItem.title}" - ${newsItem.summary} Source: ${newsItem.source}, published at ${new Date(newsItem.publishedAt).toLocaleString()}.`,
            sources: [
              {
                name: newsItem.source,
                url: newsItem.url,
                timestamp: newsItem.publishedAt
              }
            ],
            mcpData: true
          };
        }
      }
      
      // Default response for other queries
      return {
        text: `I'd be happy to help you with that query. As an MCP-enabled agent, I can access real-time financial data, crypto prices, and market news. Try asking me about Bitcoin price, Ethereum trends, or the latest market news.`,
        mcpData: false
      };
    } catch (error) {
      console.error('Error in MCPAgent.processQuery:', error);
      return {
        text: `I'm sorry, I encountered an error while processing your request: ${(error as Error).message}. Please try again later.`,
        mcpData: false
      };
    }
  }
  
  private isFinancialQuery(query: string): boolean {
    const financialKeywords = [
      'price', 'market', 'stock', 'crypto', 'bitcoin', 'btc', 'ethereum', 'eth',
      'trading', 'investment', 'finance', 'financial', 'currency', 'dollar', 'euro',
      'portfolio', 'value', 'worth', 'cost', 'expensive', 'cheap', 'volume', 'trend'
    ];
    
    return financialKeywords.some(keyword => query.toLowerCase().includes(keyword));
  }
  
  private isMarketOverviewQuery(query: string): boolean {
    const overviewKeywords = [
      'market', 'overview', 'summary', 'general', 'overall', 'trending',
      'how is the market', 'market conditions', 'market status', 'market sentiment'
    ];
    
    return overviewKeywords.some(keyword => query.toLowerCase().includes(keyword));
  }
  
  private isNewsQuery(query: string): boolean {
    const newsKeywords = [
      'news', 'announcement', 'report', 'reported', 'article', 'published',
      'recent', 'latest', 'update', 'headline', 'story', 'press release'
    ];
    
    return newsKeywords.some(keyword => query.toLowerCase().includes(keyword));
  }
  
  private extractNewsTopic(query: string): string {
    if (query.toLowerCase().includes('bitcoin') || query.toLowerCase().includes('btc')) {
      return 'bitcoin';
    } else if (query.toLowerCase().includes('ethereum') || query.toLowerCase().includes('eth')) {
      return 'ethereum';
    } else if (query.toLowerCase().includes('crypto')) {
      return 'cryptocurrency';
    } else if (query.toLowerCase().includes('finance')) {
      return 'finance';
    } else if (query.toLowerCase().includes('market')) {
      return 'market';
    } else {
      return 'cryptocurrency'; // Default topic
    }
  }
  
  getName(): string {
    return this.name;
  }
  
  getModel(): string {
    return this.model;
  }
  
  getSystemPrompt(): string {
    return this.systemPrompt;
  }
  
  getMCPClient(): MCPClient {
    return this.mcpClient;
  }
}
