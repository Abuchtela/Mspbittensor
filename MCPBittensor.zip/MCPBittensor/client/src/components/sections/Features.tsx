const Features = () => {
  return (
    <section className="py-16 px-4 bg-neutral-800/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Why MCP Matters for AI Agents</h2>
          <p className="text-neutral-300 max-w-2xl mx-auto">MCP standardizes how AI applications connect to different data sources and tools, similar to how USB-C standardized physical connections.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-neutral-800/50 border border-neutral-700 rounded-lg p-6 hover:border-primary/50 transition duration-300">
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-refresh-line text-primary text-2xl"></i>
            </div>
            <h3 className="font-display text-xl font-bold mb-2">Real-Time Data</h3>
            <p className="text-neutral-300">Connect to live data sources instead of relying on outdated training data for timely and accurate insights.</p>
          </div>
          
          <div className="bg-neutral-800/50 border border-neutral-700 rounded-lg p-6 hover:border-primary/50 transition duration-300">
            <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-plug-2-line text-secondary text-2xl"></i>
            </div>
            <h3 className="font-display text-xl font-bold mb-2">Standardized Plugins</h3>
            <p className="text-neutral-300">Easily integrate multiple data sources and tools with a consistent interface for developers.</p>
          </div>
          
          <div className="bg-neutral-800/50 border border-neutral-700 rounded-lg p-6 hover:border-primary/50 transition duration-300">
            <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-settings-line text-accent text-2xl"></i>
            </div>
            <h3 className="font-display text-xl font-bold mb-2">Contextual Awareness</h3>
            <p className="text-neutral-300">Empower agents to understand and respond to the current state of the world rather than a fixed point in time.</p>
          </div>
        </div>
        
        <div className="mt-16">
          <div className="bg-gradient-to-r from-neutral-800 to-neutral-900 border border-neutral-700 rounded-lg overflow-hidden">
            <div className="grid md:grid-cols-2">
              <div className="p-8 md:p-10">
                <h3 className="font-display text-2xl font-bold mb-4">Static vs. MCP-Enabled AI</h3>
                <p className="text-neutral-300 mb-6">See how MCP transforms AI capabilities by connecting to dynamic data sources in real-time.</p>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center mb-2">
                      <div className="w-6 h-6 rounded-full bg-neutral-700 flex items-center justify-center mr-2">
                        <i className="ri-close-line text-error"></i>
                      </div>
                      <h4 className="font-medium">Static Models</h4>
                    </div>
                    <div className="pl-8 text-neutral-400">
                      <p>• Limited to training data cut-off date</p>
                      <p>• Cannot access current market prices</p>
                      <p>• No ability to retrieve breaking news</p>
                      <p>• Unable to execute transactions</p>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center mb-2">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-2">
                        <i className="ri-check-line text-success"></i>
                      </div>
                      <h4 className="font-medium">MCP-Enabled Agents</h4>
                    </div>
                    <div className="pl-8 text-neutral-400">
                      <p>• Connect to real-time financial APIs</p>
                      <p>• Query latest market conditions</p>
                      <p>• Access breaking news and events</p>
                      <p>• Interact with on-chain data</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-neutral-900 p-8 flex items-center justify-center">
                <div className="relative max-w-md">
                  <svg width="360" height="220" viewBox="0 0 360 220" className="mx-auto">
                    {/* Static model visualization */}
                    <g transform="translate(30, 40)">
                      <rect x="0" y="0" width="120" height="60" rx="8" fill="#1E293B" stroke="#334155" strokeWidth="1.5"/>
                      <text x="60" y="35" fontSize="14" fill="#CBD5E1" textAnchor="middle">Static LLM</text>
                      
                      <rect x="0" y="100" width="120" height="60" rx="8" fill="#1E293B" stroke="#334155" strokeWidth="1.5"/>
                      <text x="60" y="135" fontSize="14" fill="#CBD5E1" textAnchor="middle">Static Response</text>
                      
                      <line x1="60" y1="60" x2="60" y2="100" stroke="#334155" strokeWidth="2"/>
                      <polygon points="60,100 55,90 65,90" fill="#334155"/>
                      
                      <text x="60" y="-10" fontSize="12" fill="#64748B" textAnchor="middle">Without MCP</text>
                    </g>
                    
                    {/* MCP model visualization */}
                    <g transform="translate(210, 40)">
                      <rect x="0" y="0" width="120" height="60" rx="8" fill="#0066FF" stroke="#004ECC" strokeWidth="1.5"/>
                      <text x="60" y="35" fontSize="14" fill="white" textAnchor="middle">MCP-Enabled LLM</text>
                      
                      <circle cx="10" cy="30" r="18" fill="#0F172A" stroke="#334155" strokeWidth="1.5"/>
                      <text x="10" y="34" fontSize="10" fill="#CBD5E1" textAnchor="middle">API</text>
                      
                      <circle cx="110" cy="30" r="18" fill="#0F172A" stroke="#334155" strokeWidth="1.5"/>
                      <text x="110" y="34" fontSize="10" fill="#CBD5E1" textAnchor="middle">Web</text>
                      
                      <rect x="0" y="100" width="120" height="60" rx="8" fill="#0066FF" stroke="#004ECC" strokeWidth="1.5"/>
                      <text x="60" y="135" fontSize="14" fill="white" textAnchor="middle">Dynamic Response</text>
                      
                      <line x1="60" y1="60" x2="60" y2="100" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
                      <polygon points="60,100 55,90 65,90" fill="#0066FF"/>
                      
                      <text x="60" y="-10" fontSize="12" fill="#64748B" textAnchor="middle">With MCP</text>
                    </g>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
