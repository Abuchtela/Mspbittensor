import { useState } from 'react';

const Documentation = () => {
  const [activeSection, setActiveSection] = useState('getting-started');
  
  return (
    <section id="documentation" className="py-16 px-4 bg-neutral-800/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">MCP Documentation</h2>
          <p className="text-neutral-300 max-w-2xl mx-auto">Learn how to implement MCP in your agent to connect to real-time data sources.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <div className="sticky top-24">
              <div className="bg-neutral-800 border border-neutral-700 rounded-lg overflow-hidden">
                <div className="px-4 py-3 border-b border-neutral-700">
                  <h3 className="font-medium">Documentation Index</h3>
                </div>
                <nav className="p-4">
                  <ul className="space-y-3">
                    <li>
                      <a 
                        href="#getting-started" 
                        className={`flex items-center ${activeSection === 'getting-started' ? 'text-primary' : 'text-neutral-300 hover:text-primary transition'}`}
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('getting-started');
                        }}
                      >
                        <span className={`w-6 h-6 flex items-center justify-center mr-2 ${activeSection === 'getting-started' ? 'bg-primary/20' : 'bg-neutral-700'} rounded-full text-xs`}>1</span>
                        Getting Started
                      </a>
                    </li>
                    <li>
                      <a 
                        href="#mcp-structure" 
                        className={`flex items-center ${activeSection === 'mcp-structure' ? 'text-primary' : 'text-neutral-300 hover:text-primary transition'}`}
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('mcp-structure');
                        }}
                      >
                        <span className={`w-6 h-6 flex items-center justify-center mr-2 ${activeSection === 'mcp-structure' ? 'bg-primary/20' : 'bg-neutral-700'} rounded-full text-xs`}>2</span>
                        MCP Structure
                      </a>
                    </li>
                    <li>
                      <a 
                        href="#implementing-plugins" 
                        className={`flex items-center ${activeSection === 'implementing-plugins' ? 'text-primary' : 'text-neutral-300 hover:text-primary transition'}`}
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('implementing-plugins');
                        }}
                      >
                        <span className={`w-6 h-6 flex items-center justify-center mr-2 ${activeSection === 'implementing-plugins' ? 'bg-primary/20' : 'bg-neutral-700'} rounded-full text-xs`}>3</span>
                        Implementing Plugins
                      </a>
                    </li>
                    <li>
                      <a 
                        href="#error-handling" 
                        className={`flex items-center ${activeSection === 'error-handling' ? 'text-primary' : 'text-neutral-300 hover:text-primary transition'}`}
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('error-handling');
                        }}
                      >
                        <span className={`w-6 h-6 flex items-center justify-center mr-2 ${activeSection === 'error-handling' ? 'bg-primary/20' : 'bg-neutral-700'} rounded-full text-xs`}>4</span>
                        Error Handling
                      </a>
                    </li>
                    <li>
                      <a 
                        href="#best-practices" 
                        className={`flex items-center ${activeSection === 'best-practices' ? 'text-primary' : 'text-neutral-300 hover:text-primary transition'}`}
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('best-practices');
                        }}
                      >
                        <span className={`w-6 h-6 flex items-center justify-center mr-2 ${activeSection === 'best-practices' ? 'bg-primary/20' : 'bg-neutral-700'} rounded-full text-xs`}>5</span>
                        Best Practices
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <div className="bg-neutral-800 border border-neutral-700 rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-neutral-700">
                <h3 className="font-medium" id="getting-started">
                  {activeSection === 'getting-started' && 'Getting Started with MCP'}
                  {activeSection === 'mcp-structure' && 'MCP Structure'}
                  {activeSection === 'implementing-plugins' && 'Implementing Plugins'}
                  {activeSection === 'error-handling' && 'Error Handling'}
                  {activeSection === 'best-practices' && 'Best Practices'}
                </h3>
              </div>
              <div className="p-6">
                {activeSection === 'getting-started' && (
                  <>
                    <p className="mb-4">MCP (Model Control Protocol) allows AI agents to connect to real-time data sources, making them context-aware and more capable.</p>
                
                    <h4 className="font-medium text-lg mb-2 mt-6">Installation</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6 font-mono text-sm overflow-x-auto">
                      <code>npm install @masa/mcp-core @masa/mcp-plugins</code>
                    </div>
                    
                    <h4 className="font-medium text-lg mb-2">Basic Usage</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-4 font-mono text-sm overflow-x-auto">
    <code>{`import { MCPAgent } from '@masa/mcp-core';
import { FinancePlugin, NewsPlugin } from '@masa/mcp-plugins';

// Initialize the MCP agent
const agent = new MCPAgent({
  model: 'openai/gpt-4',
  plugins: [
    new FinancePlugin({ apiKey: 'your-api-key' }),
    new NewsPlugin({ apiKey: 'your-api-key' })
  ],
  systemPrompt: 'You are a financial assistant with real-time data access.'
});

// Handle user queries
async function handleQuery(userQuery) {
  const response = await agent.process(userQuery);
  return response;
}`}</code>
                    </div>
                    
                    <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 mb-6">
                      <div className="flex items-start">
                        <i className="ri-information-line text-primary mt-1 mr-3"></i>
                        <div>
                          <h4 className="font-medium text-primary mb-1">MCP vs. Static Models</h4>
                          <p className="text-sm">When implementing MCP, your agent gains the ability to access real-time data that would be impossible with static models. For example, a financial agent can retrieve current market prices, breaking news, and on-chain data to provide accurate, up-to-date insights.</p>
                        </div>
                      </div>
                    </div>
                    
                    <h4 className="font-medium text-lg mb-2">Implementing for Bittensor</h4>
                    <p className="mb-4">To implement MCP on Bittensor, you'll need to connect to the appropriate subnet validators:</p>
                    
                    <div className="bg-neutral-900 p-4 rounded-lg mb-4 font-mono text-sm overflow-x-auto">
    <code>{`import { MCPAgent } from '@masa/mcp-core';
import { BittensorPlugin } from '@masa/mcp-plugins-bittensor';

// Initialize with Bittensor support
const agent = new MCPAgent({
  model: 'openai/gpt-4',
  plugins: [
    new BittensorPlugin({
      subnet: '42', // For financial data subnet
      endpoint: 'your-validator-endpoint'
    })
  ],
  systemPrompt: 'You are a financial assistant powered by Bittensor.'
});`}</code>
                    </div>
                    
                    <div className="flex justify-end mt-6">
                      <a 
                        href="#mcp-structure" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('mcp-structure');
                        }}
                      >
                        Next: MCP Structure
                        <i className="ri-arrow-right-line ml-1"></i>
                      </a>
                    </div>
                  </>
                )}
                
                {activeSection === 'mcp-structure' && (
                  <>
                    <p className="mb-4">MCP provides a standardized way for AI models to access external data and tools. Understanding its structure helps you build effective agents.</p>
                    
                    <h4 className="font-medium text-lg mb-2 mt-6">Core Components</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6">
                      <ul className="space-y-3">
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">1</div>
                          <div>
                            <h5 className="font-medium mb-1">MCPAgent</h5>
                            <p className="text-sm text-neutral-300">The main agent that coordinates between the AI model and plugins.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">2</div>
                          <div>
                            <h5 className="font-medium mb-1">Plugins</h5>
                            <p className="text-sm text-neutral-300">Modules that connect to specific data sources or tools with standardized interfaces.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">3</div>
                          <div>
                            <h5 className="font-medium mb-1">Data Connector</h5>
                            <p className="text-sm text-neutral-300">Handles the actual data retrieval and API connections.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">4</div>
                          <div>
                            <h5 className="font-medium mb-1">Context Manager</h5>
                            <p className="text-sm text-neutral-300">Enriches user queries with relevant context from plugins.</p>
                          </div>
                        </li>
                      </ul>
                    </div>
                    
                    <h4 className="font-medium text-lg mb-2">Data Flow</h4>
                    <p className="mb-4">The diagram below illustrates how data flows through an MCP-enabled agent:</p>
                    
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6 text-center">
                      <svg width="100%" height="240" viewBox="0 0 400 240" className="mx-auto">
                        {/* User Query */}
                        <rect x="150" y="10" width="100" height="40" rx="4" fill="#334155" stroke="#64748B" strokeWidth="1"/>
                        <text x="200" y="35" textAnchor="middle" fill="#F8FAFC" fontSize="12">User Query</text>
                        
                        {/* Context Manager */}
                        <rect x="150" y="80" width="100" height="40" rx="4" fill="#7B61FF" stroke="#6345FF" strokeWidth="1"/>
                        <text x="200" y="105" textAnchor="middle" fill="#F8FAFC" fontSize="12">Context Manager</text>
                        
                        {/* Data Connector */}
                        <rect x="30" y="150" width="100" height="40" rx="4" fill="#00DBC2" stroke="#00B99E" strokeWidth="1"/>
                        <text x="80" y="175" textAnchor="middle" fill="#0F172A" fontSize="12">Data Connector</text>
                        
                        {/* MCPAgent */}
                        <rect x="150" y="150" width="100" height="40" rx="4" fill="#0066FF" stroke="#004ECC" strokeWidth="1"/>
                        <text x="200" y="175" textAnchor="middle" fill="#F8FAFC" fontSize="12">MCP Agent</text>
                        
                        {/* External APIs */}
                        <rect x="270" y="150" width="100" height="40" rx="4" fill="#334155" stroke="#64748B" strokeWidth="1"/>
                        <text x="320" y="175" textAnchor="middle" fill="#F8FAFC" fontSize="12">Plugin Modules</text>
                        
                        {/* Response */}
                        <rect x="150" y="220" width="100" height="40" rx="4" fill="#0066FF" stroke="#004ECC" strokeWidth="1"/>
                        <text x="200" y="245" textAnchor="middle" fill="#F8FAFC" fontSize="12">Agent Response</text>
                        
                        {/* Flow lines */}
                        <line x1="200" y1="50" x2="200" y2="80" stroke="#64748B" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="200,80 195,70 205,70" fill="#64748B"/>
                        
                        <line x1="150" y1="100" x2="80" y2="150" stroke="#7B61FF" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="80,150 85,140 95,145" fill="#7B61FF"/>
                        
                        <line x1="200" y1="120" x2="200" y2="150" stroke="#7B61FF" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="200,150 195,140 205,140" fill="#7B61FF"/>
                        
                        <line x1="250" y1="100" x2="320" y2="150" stroke="#7B61FF" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="320,150 310,145 315,135" fill="#7B61FF"/>
                        
                        <line x1="130" y1="170" x2="150" y2="170" stroke="#00DBC2" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="150,170 140,165 140,175" fill="#00DBC2"/>
                        
                        <line x1="250" y1="170" x2="270" y2="170" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="270,170 260,165 260,175" fill="#0066FF"/>
                        
                        <line x1="200" y1="190" x2="200" y2="220" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
                        <polygon points="200,220 195,210 205,210" fill="#0066FF"/>
                      </svg>
                    </div>
                    
                    <div className="flex justify-between mt-6">
                      <a 
                        href="#getting-started" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('getting-started');
                        }}
                      >
                        <i className="ri-arrow-left-line mr-1"></i>
                        Back: Getting Started
                      </a>
                      <a 
                        href="#implementing-plugins" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('implementing-plugins');
                        }}
                      >
                        Next: Implementing Plugins
                        <i className="ri-arrow-right-line ml-1"></i>
                      </a>
                    </div>
                  </>
                )}
                
                {activeSection === 'implementing-plugins' && (
                  <>
                    <p className="mb-4">Plugins are the key components that enable MCP to access different data sources. Here's how to implement them.</p>
                    
                    <h4 className="font-medium text-lg mb-2 mt-6">Creating a Custom Plugin</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6 font-mono text-sm overflow-x-auto">
    <code>{`import { MCPPlugin, MCPRequest, MCPResponse } from '@masa/mcp-core';

class CryptoMarketPlugin extends MCPPlugin {
  private apiKey: string;
  
  constructor(options: { apiKey: string }) {
    super({ name: 'crypto-market' });
    this.apiKey = options.apiKey;
  }
  
  async processRequest(request: MCPRequest): Promise<MCPResponse> {
    // Check if this plugin can handle the request
    if (!this.canHandleRequest(request)) {
      return { status: 'error', message: 'Request not supported by this plugin' };
    }
    
    try {
      // Make API call to get crypto data
      const response = await fetch(\`https://api.example.com/crypto?api_key=\${this.apiKey}\`);
      const data = await response.json();
      
      return {
        status: 'success',
        data: data,
        source: 'CryptoMarket API',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return {
        status: 'error',
        message: \`Error fetching crypto data: \${error.message}\`
      };
    }
  }
  
  canHandleRequest(request: MCPRequest): boolean {
    // Check if the request is related to cryptocurrency
    return request.query.toLowerCase().includes('crypto') || 
           request.query.toLowerCase().includes('bitcoin') ||
           request.query.toLowerCase().includes('ethereum');
  }
}`}</code>
                    </div>
                    
                    <h4 className="font-medium text-lg mb-2">Registering Your Plugin</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-4 font-mono text-sm overflow-x-auto">
    <code>{`import { MCPAgent } from '@masa/mcp-core';
import { CryptoMarketPlugin } from './plugins/crypto-market';

// Initialize the agent with your custom plugin
const agent = new MCPAgent({
  model: 'openai/gpt-4',
  plugins: [
    new CryptoMarketPlugin({ apiKey: process.env.CRYPTO_API_KEY || 'your-api-key' })
  ],
  systemPrompt: 'You are a crypto market analyst with access to real-time data.'
});`}</code>
                    </div>
                    
                    <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 mb-6">
                      <div className="flex items-start">
                        <i className="ri-lightbulb-line text-primary mt-1 mr-3"></i>
                        <div>
                          <h4 className="font-medium text-primary mb-1">Plugin Best Practices</h4>
                          <ul className="text-sm space-y-1">
                            <li>• Implement robust error handling for API failures</li>
                            <li>• Include rate limiting to avoid API throttling</li>
                            <li>• Always specify data sources and timestamps</li>
                            <li>• Cache frequently accessed data when appropriate</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between mt-6">
                      <a 
                        href="#mcp-structure" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('mcp-structure');
                        }}
                      >
                        <i className="ri-arrow-left-line mr-1"></i>
                        Back: MCP Structure
                      </a>
                      <a 
                        href="#error-handling" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('error-handling');
                        }}
                      >
                        Next: Error Handling
                        <i className="ri-arrow-right-line ml-1"></i>
                      </a>
                    </div>
                  </>
                )}
                
                {activeSection === 'error-handling' && (
                  <>
                    <p className="mb-4">Proper error handling is crucial when working with external APIs through MCP. Here's how to implement robust error handling.</p>
                    
                    <h4 className="font-medium text-lg mb-2 mt-6">Common Error Scenarios</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6">
                      <ul className="space-y-3">
                        <li className="flex items-start">
                          <div className="text-error mr-2 mt-0.5">
                            <i className="ri-error-warning-line"></i>
                          </div>
                          <div>
                            <h5 className="font-medium mb-1">API Connection Failures</h5>
                            <p className="text-sm text-neutral-300">When external APIs are unreachable or return server errors.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="text-error mr-2 mt-0.5">
                            <i className="ri-error-warning-line"></i>
                          </div>
                          <div>
                            <h5 className="font-medium mb-1">Rate Limiting</h5>
                            <p className="text-sm text-neutral-300">When too many requests are made to an API in a short period.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="text-error mr-2 mt-0.5">
                            <i className="ri-error-warning-line"></i>
                          </div>
                          <div>
                            <h5 className="font-medium mb-1">Authentication Failures</h5>
                            <p className="text-sm text-neutral-300">When API keys are invalid or expired.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="text-error mr-2 mt-0.5">
                            <i className="ri-error-warning-line"></i>
                          </div>
                          <div>
                            <h5 className="font-medium mb-1">Data Parsing Errors</h5>
                            <p className="text-sm text-neutral-300">When API responses don't match expected formats.</p>
                          </div>
                        </li>
                      </ul>
                    </div>
                    
                    <h4 className="font-medium text-lg mb-2">Implementing Error Handling</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6 font-mono text-sm overflow-x-auto">
    <code>{`// Custom MCP Error class
class MCPError extends Error {
  constructor(
    message: string,
    public statusCode?: number,
    public source?: string,
    public retryable: boolean = false
  ) {
    super(message);
    this.name = 'MCPError';
  }
}

// Using try-catch in your plugin
async processRequest(request: MCPRequest): Promise<MCPResponse> {
  try {
    // API call logic here
    const response = await fetch(url, options);
    
    // Check for HTTP errors
    if (!response.ok) {
      const retryable = response.status >= 500 || response.status === 429;
      throw new MCPError(
        \`API error: \${response.statusText}\`,
        response.status,
        this.name,
        retryable
      );
    }
    
    const data = await response.json();
    return {
      status: 'success',
      data: data,
      source: this.name,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    // Log the error for debugging
    console.error('[MCP Plugin Error]', error);
    
    if (error instanceof MCPError) {
      // Handle known MCP errors
      return {
        status: 'error',
        message: error.message,
        source: error.source,
        retryable: error.retryable
      };
    }
    
    // Handle unexpected errors
    return {
      status: 'error',
      message: \`Unexpected error: \${error.message}\`,
      source: this.name,
      retryable: false
    };
  }
}`}</code>
                    </div>
                    
                    <h4 className="font-medium text-lg mb-2">Graceful Fallbacks</h4>
                    <p className="mb-4">Implement fallback strategies when primary data sources are unavailable:</p>
                    
                    <div className="bg-neutral-900 p-4 rounded-lg mb-4 font-mono text-sm overflow-x-auto">
    <code>{`// Implementing fallback strategies
async getCryptoPrice(symbol: string): Promise<any> {
  try {
    // Try primary API first
    return await this.fetchFromPrimaryAPI(symbol);
  } catch (error) {
    console.warn(\`Primary API failed: \${error.message}. Trying fallback...\`);
    
    try {
      // Try secondary API as fallback
      return await this.fetchFromSecondaryAPI(symbol);
    } catch (secondaryError) {
      // Both APIs failed
      throw new MCPError(
        \`All data sources failed: \${error.message} and \${secondaryError.message}\`,
        500,
        this.name,
        false
      );
    }
  }
}`}</code>
                    </div>
                    
                    <div className="flex justify-between mt-6">
                      <a 
                        href="#implementing-plugins" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('implementing-plugins');
                        }}
                      >
                        <i className="ri-arrow-left-line mr-1"></i>
                        Back: Implementing Plugins
                      </a>
                      <a 
                        href="#best-practices" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('best-practices');
                        }}
                      >
                        Next: Best Practices
                        <i className="ri-arrow-right-line ml-1"></i>
                      </a>
                    </div>
                  </>
                )}
                
                {activeSection === 'best-practices' && (
                  <>
                    <p className="mb-4">Follow these best practices to build robust and efficient MCP-enabled agents.</p>
                    
                    <h4 className="font-medium text-lg mb-2 mt-6">Performance Optimization</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <i className="ri-check-line text-success mt-1 mr-2"></i>
                        <span>Implement caching for frequently accessed data</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-check-line text-success mt-1 mr-2"></i>
                        <span>Use connection pooling for database or API connections</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-check-line text-success mt-1 mr-2"></i>
                        <span>Batch API requests when possible to reduce network overhead</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-check-line text-success mt-1 mr-2"></i>
                        <span>Implement circuit breakers to prevent cascading failures</span>
                      </li>
                    </ul>
                    
                    <h4 className="font-medium text-lg mb-2">Security Considerations</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <i className="ri-shield-check-line text-primary mt-1 mr-2"></i>
                        <span>Never expose API keys in client-side code</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-shield-check-line text-primary mt-1 mr-2"></i>
                        <span>Implement proper rate limiting to protect external APIs</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-shield-check-line text-primary mt-1 mr-2"></i>
                        <span>Validate and sanitize all user inputs before processing</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-shield-check-line text-primary mt-1 mr-2"></i>
                        <span>Use secure connections (HTTPS) for all API requests</span>
                      </li>
                    </ul>
                    
                    <h4 className="font-medium text-lg mb-2">Designing for Bittensor</h4>
                    <div className="bg-neutral-900 p-4 rounded-lg mb-6">
                      <ul className="space-y-3">
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-secondary/20 text-secondary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">1</div>
                          <div>
                            <h5 className="font-medium mb-1">Incentive Alignment</h5>
                            <p className="text-sm text-neutral-300">Design your MCP agent to align with Bittensor's incentive mechanics and validator requirements.</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-secondary/20 text-secondary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">2</div>
                          <div>
                            <h5 className="font-medium mb-1">Subnet Compatibility</h5>
                            <p className="text-sm text-neutral-300">Ensure your plugins are compatible with the specific subnets you're targeting (Subnet 42 for financial data, Subnet 59 for agent arena).</p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-secondary/20 text-secondary flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">3</div>
                          <div>
                            <h5 className="font-medium mb-1">Decentralized Architecture</h5>
                            <p className="text-sm text-neutral-300">Design your MCP implementation to work effectively in Bittensor's decentralized environment.</p>
                          </div>
                        </li>
                      </ul>
                    </div>
                    
                    <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 mb-6">
                      <div className="flex items-start">
                        <i className="ri-lightbulb-line text-primary mt-1 mr-3"></i>
                        <div>
                          <h4 className="font-medium text-primary mb-1">MCP Development Tips</h4>
                          <p className="text-sm">When developing for the hackathon, focus on demonstrating clear comparison between static and MCP-enabled models. Show specific examples where real-time data significantly improves the quality of responses.</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-start mt-6">
                      <a 
                        href="#error-handling" 
                        className="inline-flex items-center text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          setActiveSection('error-handling');
                        }}
                      >
                        <i className="ri-arrow-left-line mr-1"></i>
                        Back: Error Handling
                      </a>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Documentation;
