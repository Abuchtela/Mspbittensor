import { useRef, useEffect, useState } from 'react';
import VolumeChart from '../ui/volume-chart';

const Hero = () => {
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [userInput, setUserInput] = useState('');
  
  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  };
  
  useEffect(() => {
    scrollToBottom();
  }, []);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;
    
    // For now we'll implement a static response since this is just a demo interface
    scrollToBottom();
    setUserInput('');
  };
  
  return (
    <section className="py-16 md:py-24 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col md:flex-row md:space-x-12 items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <span className="bg-accent/20 text-accent px-3 py-1 rounded-full text-sm font-medium">Real-time Data Access</span>
            <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Build Context-Aware AI with <span className="text-primary">MCP</span>
            </h1>
            <p className="text-neutral-300 text-lg mb-8">
              Enhance your AI agents with Model Control Protocol (MCP), enabling them to connect to real-time data sources for more accurate and contextually relevant responses.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <a href="#agent-builder" className="inline-flex items-center justify-center bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-lg font-medium transition-colors">
                <span>Try MCP Agent Builder</span>
                <i className="ri-arrow-right-line ml-2"></i>
              </a>
              <a href="#documentation" className="inline-flex items-center justify-center border border-neutral-700 hover:border-neutral-500 px-6 py-3 rounded-lg font-medium transition-colors">
                View Documentation
              </a>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="relative bg-neutral-800 border border-neutral-700 rounded-lg p-6 shadow-lg">
              <div className="absolute -top-3 -right-3 bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-sm font-mono flex items-center">
                <span className="w-2 h-2 bg-success rounded-full mr-1"></span>
                MCP Connected
              </div>
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-primary/20 text-primary rounded flex items-center justify-center">
                    <i className="ri-robot-line"></i>
                  </div>
                  <span className="ml-2 font-medium">Financial Agent</span>
                </div>
                <div className="flex space-x-1 text-neutral-500">
                  <button className="hover:text-white transition" aria-label="Refresh">
                    <i className="ri-refresh-line"></i>
                  </button>
                  <button className="hover:text-white transition" aria-label="Settings">
                    <i className="ri-settings-3-line"></i>
                  </button>
                </div>
              </div>
              
              <div className="space-y-4 h-72 overflow-y-auto pr-2" ref={chatContainerRef}>
                <div className="flex space-x-2">
                  <div className="w-8 h-8 bg-neutral-700 rounded-full flex-shrink-0 flex items-center justify-center">
                    <i className="ri-user-line"></i>
                  </div>
                  <div className="bg-neutral-700 rounded-lg p-3 max-w-[85%]">
                    <p>What's the current Bitcoin price and how has it changed in the last 24 hours?</p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <div className="w-8 h-8 bg-primary rounded-full flex-shrink-0 flex items-center justify-center">
                    <i className="ri-robot-line"></i>
                  </div>
                  <div className="bg-neutral-800 border border-neutral-700 rounded-lg p-3 max-w-[85%]">
                    <p className="mb-3">Bitcoin is currently trading at <span className="font-medium text-white">$68,223.45</span>. In the last 24 hours:</p>
                    <div className="bg-neutral-900 p-3 rounded-md flex items-center mb-3">
                      <i className="ri-arrow-up-line text-success text-lg mr-2"></i>
                      <div>
                        <div className="font-medium text-white">+2.7%</div>
                        <div className="text-sm text-neutral-400">24h change</div>
                      </div>
                      <div className="ml-auto bg-neutral-800 rounded px-2 py-1 text-xs">
                        Live data via MCP
                      </div>
                    </div>
                    <p className="text-sm text-neutral-400">Data sourced from Coinbase API and updated 30 seconds ago.</p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <div className="w-8 h-8 bg-neutral-700 rounded-full flex-shrink-0 flex items-center justify-center">
                    <i className="ri-user-line"></i>
                  </div>
                  <div className="bg-neutral-700 rounded-lg p-3 max-w-[85%]">
                    <p>What's the trading volume compared to last week?</p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <div className="w-8 h-8 bg-primary rounded-full flex-shrink-0 flex items-center justify-center">
                    <i className="ri-robot-line"></i>
                  </div>
                  <div className="bg-neutral-800 border border-neutral-700 rounded-lg p-3 max-w-[85%]">
                    <p className="mb-3">Bitcoin's current 24h trading volume is <span className="font-medium text-white">$42.3 billion</span>, which is:</p>
                    <div className="h-32 mb-3 bg-neutral-900 p-3 rounded-md">
                      <VolumeChart />
                    </div>
                    <p>This represents a <span className="text-success">+12.8%</span> increase compared to last week's average daily volume of $37.5 billion.</p>
                    <div className="mt-2 text-sm text-neutral-400 flex items-center">
                      <i className="ri-information-line mr-1"></i>
                      <span>Without MCP, this comparison would not be possible as static models lack real-time volume data.</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <form className="mt-4 relative" onSubmit={handleSubmit}>
                <input 
                  type="text" 
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg py-3 px-4 pr-10 focus:outline-none focus:border-primary placeholder-neutral-500" 
                  placeholder="Ask about market data..."
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                />
                <button 
                  type="submit"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-primary hover:text-white transition"
                  aria-label="Send message"
                >
                  <i className="ri-send-plane-fill"></i>
                </button>
              </form>
            </div>
            <div className="absolute -bottom-4 -right-4 -z-10 w-full h-full bg-gradient-to-br from-primary to-secondary opacity-20 rounded-lg blur-lg"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
