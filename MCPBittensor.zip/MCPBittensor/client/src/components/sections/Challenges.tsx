const Challenges = () => {
  return (
    <section id="use-cases" className="py-16 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">MCP Use Cases</h2>
          <p className="text-neutral-300 max-w-2xl mx-auto">Explore the capabilities of Model Control Protocol (MCP) with these powerful real-world applications.</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/30 rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-primary/30 flex items-center justify-between">
              <h3 className="font-medium flex items-center">
                <span className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-2 text-sm"><i className="ri-plug-line"></i></span>
                Plugin Development
              </h3>
            </div>
            <div className="p-6">
              <p className="mb-4">Build powerful MCP plugins that connect AI models to real-time data sources and enhance their capabilities.</p>
              
              <h4 className="font-medium text-lg mb-2 mt-4">Key Benefits</h4>
              <ul className="space-y-2 mb-6">
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-primary mt-1 mr-2"></i>
                  <span>Create MCP plugins that connect to valuable data sources</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-primary mt-1 mr-2"></i>
                  <span>Implement proper error handling and rate limiting</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-primary mt-1 mr-2"></i>
                  <span>Document your plugin's functionality and API</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-primary mt-1 mr-2"></i>
                  <span>Demonstrate usefulness in a real-world scenario</span>
                </li>
              </ul>
              
              <h4 className="font-medium text-lg mb-2">Example Plugin Types</h4>
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-bank-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">Financial Data</h5>
                </div>
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-stock-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">Market Analysis</h5>
                </div>
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-newspaper-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">News Aggregation</h5>
                </div>
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-line-chart-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">On-chain Analytics</h5>
                </div>
              </div>
              
              <button 
                className="inline-flex items-center justify-center w-full bg-primary hover:bg-primary-dark text-white px-4 py-3 rounded-lg font-medium transition-colors"
              >
                <span>Explore Plugin Development</span>
                <i className="ri-arrow-right-line ml-2"></i>
              </button>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-secondary/20 to-secondary/5 border border-secondary/30 rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-secondary/30 flex items-center justify-between">
              <h3 className="font-medium flex items-center">
                <span className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center mr-2 text-sm"><i className="ri-robot-line"></i></span>
                Agent Development
              </h3>
            </div>
            <div className="p-6">
              <p className="mb-4">Create utility-focused, context-aware agents leveraging MCP for real-world use cases and applications.</p>
              
              <h4 className="font-medium text-lg mb-2 mt-4">Key Benefits</h4>
              <ul className="space-y-2 mb-6">
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-secondary mt-1 mr-2"></i>
                  <span>Build an agent that uses MCP to access real-time data</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-secondary mt-1 mr-2"></i>
                  <span>Create a user interface for agent interaction</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-secondary mt-1 mr-2"></i>
                  <span>Visualize how data flows through your MCP implementation</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-line text-secondary mt-1 mr-2"></i>
                  <span>Demonstrate superior results vs. static models</span>
                </li>
              </ul>
              
              <h4 className="font-medium text-lg mb-2">Example Agent Types</h4>
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-funds-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">Investment Advisor</h5>
                </div>
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-coin-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">Crypto Analyst</h5>
                </div>
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-pie-chart-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">Portfolio Manager</h5>
                </div>
                <div className="bg-neutral-800/80 p-3 rounded-lg">
                  <i className="ri-alert-line text-neutral-300 mb-1"></i>
                  <h5 className="font-medium text-sm">Market Alert System</h5>
                </div>
              </div>
              
              <button
                className="inline-flex items-center justify-center w-full bg-secondary hover:bg-secondary/80 text-white px-4 py-3 rounded-lg font-medium transition-colors"
              >
                <span>Explore Agent Development</span>
                <i className="ri-arrow-right-line ml-2"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Challenges;
