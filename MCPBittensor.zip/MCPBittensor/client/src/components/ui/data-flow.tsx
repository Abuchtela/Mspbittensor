import { useEffect } from 'react';

interface DataFlowProps {
  enabledPlugins: string[];
}

const DataFlow = ({ enabledPlugins }: DataFlowProps) => {
  // Create SVG-based data flow visualization
  return (
    <svg width="400" height="280" viewBox="0 0 400 280">
      {/* User Query */}
      <rect x="10" y="10" width="100" height="40" rx="4" fill="#334155" stroke="#64748B" strokeWidth="1"/>
      <text x="60" y="35" textAnchor="middle" fill="#F8FAFC" fontSize="12">User Query</text>
      
      {/* Agent */}
      <rect x="150" y="110" width="100" height="60" rx="4" fill="#0066FF" stroke="#004ECC" strokeWidth="1"/>
      <text x="200" y="145" textAnchor="middle" fill="#F8FAFC" fontSize="12">MCP Agent</text>
      
      {/* API Connections */}
      <g opacity={enabledPlugins.includes('financial') ? "1" : "0.3"}>
        <rect x="10" y="110" width="80" height="40" rx="4" fill={enabledPlugins.includes('financial') ? "#1E293B" : "#0F172A"} stroke="#334155" strokeWidth="1"/>
        <text x="50" y="135" textAnchor="middle" fill="#F8FAFC" fontSize="10">Financial API</text>
      </g>
      
      <g opacity={enabledPlugins.includes('news') ? "1" : "0.3"}>
        <rect x="10" y="170" width="80" height="40" rx="4" fill={enabledPlugins.includes('news') ? "#1E293B" : "#0F172A"} stroke="#334155" strokeWidth="1"/>
        <text x="50" y="195" textAnchor="middle" fill="#F8FAFC" fontSize="10">News API</text>
      </g>
      
      <g opacity={enabledPlugins.includes('financial') ? "1" : "0.3"}>
        <rect x="310" y="110" width="80" height="40" rx="4" fill={enabledPlugins.includes('financial') ? "#1E293B" : "#0F172A"} stroke="#334155" strokeWidth="1"/>
        <text x="350" y="135" textAnchor="middle" fill="#F8FAFC" fontSize="10">Market Data</text>
      </g>
      
      <g opacity={enabledPlugins.includes('news') ? "1" : "0.3"}>
        <rect x="310" y="170" width="80" height="40" rx="4" fill={enabledPlugins.includes('news') ? "#1E293B" : "#0F172A"} stroke="#334155" strokeWidth="1"/>
        <text x="350" y="195" textAnchor="middle" fill="#F8FAFC" fontSize="10">Events Data</text>
      </g>
      
      {/* Response */}
      <rect x="150" y="230" width="100" height="40" rx="4" fill="#7B61FF" stroke="#6345FF" strokeWidth="1"/>
      <text x="200" y="255" textAnchor="middle" fill="#F8FAFC" fontSize="12">Agent Response</text>
      
      {/* Data Flow Lines */}
      <line x1="60" y1="50" x2="180" y2="110" stroke="#64748B" strokeWidth="2" className="data-flow-line"/>
      <polygon points="180,110 170,105 175,95" fill="#64748B"/>
      
      {enabledPlugins.includes('financial') && (
        <>
          <line x1="90" y1="130" x2="150" y2="140" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
          <polygon points="150,140 140,135 142,125" fill="#0066FF"/>
        </>
      )}
      
      {enabledPlugins.includes('news') && (
        <>
          <line x1="90" y1="190" x2="150" y2="160" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
          <polygon points="150,160 140,165 142,155" fill="#0066FF"/>
        </>
      )}
      
      {enabledPlugins.includes('financial') && (
        <>
          <line x1="250" y1="140" x2="310" y2="130" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
          <polygon points="310,130 300,135 302,125" fill="#0066FF"/>
        </>
      )}
      
      {enabledPlugins.includes('news') && (
        <>
          <line x1="250" y1="160" x2="310" y2="190" stroke="#0066FF" strokeWidth="2" className="data-flow-line"/>
          <polygon points="310,190 300,185 302,175" fill="#0066FF"/>
        </>
      )}
      
      <line x1="200" y1="170" x2="200" y2="230" stroke="#7B61FF" strokeWidth="2" className="data-flow-line"/>
      <polygon points="200,230 195,220 205,220" fill="#7B61FF"/>
    </svg>
  );
};

export default DataFlow;
