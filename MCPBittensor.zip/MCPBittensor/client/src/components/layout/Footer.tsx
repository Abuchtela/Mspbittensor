const Footer = () => {
  return (
    <footer className="border-t border-neutral-800 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-primary p-2 rounded">
                <i className="ri-plug-2-line text-xl"></i>
              </div>
              <h2 className="font-display font-bold text-xl">Masa MCP</h2>
            </div>
            <p className="text-neutral-400 mb-4">Building the standard for AI connectivity in the Bittensor ecosystem.</p>
            <div className="flex space-x-4">
              <a href="https://twitter.com" className="text-neutral-400 hover:text-white transition" aria-label="Twitter">
                <i className="ri-twitter-x-line text-lg"></i>
              </a>
              <a href="https://github.com" className="text-neutral-400 hover:text-white transition" aria-label="GitHub">
                <i className="ri-github-fill text-lg"></i>
              </a>
              <a href="https://discord.com" className="text-neutral-400 hover:text-white transition" aria-label="Discord">
                <i className="ri-discord-line text-lg"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#documentation" className="text-neutral-400 hover:text-white transition">Documentation</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">API Reference</a></li>
              <li><a href="https://github.com" className="text-neutral-400 hover:text-white transition">GitHub Repository</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Community Forum</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium mb-4">Hackathon</h3>
            <ul className="space-y-2">
              <li>
                <a 
                  href="https://bit.ly/EndGame42" 
                  className="text-neutral-400 hover:text-white transition"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Subnet 42 Challenge
                </a>
              </li>
              <li>
                <a 
                  href="https://bit.ly/EndGame59" 
                  className="text-neutral-400 hover:text-white transition"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Subnet 59 Challenge
                </a>
              </li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Submission Guidelines</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Judging Criteria</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium mb-4">Newsletter</h3>
            <p className="text-neutral-400 mb-4">Stay updated with the latest MCP developments and Bittensor news.</p>
            <form className="flex" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Your email" 
                className="flex-grow bg-neutral-800 border border-neutral-700 rounded-l-lg py-2 px-3 focus:outline-none focus:border-primary"
                aria-label="Email for newsletter"
              />
              <button 
                className="bg-primary hover:bg-primary-dark px-4 py-2 rounded-r-lg transition-colors"
                aria-label="Subscribe"
              >
                <i className="ri-mail-send-line"></i>
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-neutral-800 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-400 text-sm mb-4 md:mb-0">© 2023 Masa. All rights reserved. In partnership with Bittensor.</p>
          <div className="flex space-x-6">
            <a href="#" className="text-neutral-400 hover:text-white text-sm transition">Terms</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm transition">Privacy</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm transition">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
