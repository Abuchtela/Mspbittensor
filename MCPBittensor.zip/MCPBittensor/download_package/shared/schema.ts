import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for basic user accounts
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Agent schema to store agent configurations
export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  baseModel: text("base_model").notNull(),
  systemPrompt: text("system_prompt").notNull(),
  plugins: jsonb("plugins").notNull().$type<string[]>(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAgentSchema = createInsertSchema(agents).pick({
  name: true,
  baseModel: true,
  systemPrompt: true,
  plugins: true,
  userId: true,
});

// Chat messages schema to store user interactions with agents
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  agentId: integer("agent_id").references(() => agents.id),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  isUserMessage: boolean("is_user_message").notNull(),
  mcpDataUsed: boolean("mcp_data_used").default(false),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  userId: true,
  agentId: true,
  content: true,
  isUserMessage: true,
  mcpDataUsed: true,
});

// Define data plugin types available for agents
export const dataPluginSchema = z.object({
  id: z.string(),
  name: z.string(),
  enabled: z.boolean(),
  apiKey: z.string().optional(),
});

// Types for our schema
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Agent = typeof agents.$inferSelect;

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

export type DataPlugin = z.infer<typeof dataPluginSchema>;
